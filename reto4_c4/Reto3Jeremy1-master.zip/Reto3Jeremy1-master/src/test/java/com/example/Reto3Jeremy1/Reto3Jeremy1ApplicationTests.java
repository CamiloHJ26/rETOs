package com.example.Reto3Jeremy1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3Jeremy1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
